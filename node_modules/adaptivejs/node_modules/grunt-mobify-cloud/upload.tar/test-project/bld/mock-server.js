var express = require('express');
var fs = require('fs');
var path = require('path');
var https = require('https');
var app = express();

app.use(express.urlencoded());

// Allow self-signed test certs to work
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

// Add options needed to create an https server
var options = {
    key: fs.readFileSync('test/fixtures/test-key.pem'),
    cert: fs.readFileSync('test/fixtures/test-cert.pem')
};

app.post('/api/projects/:project/builds/', function(req, res) {
    var body = '';
    req.on('data', function(data){
        body += data;
    });

    // Write out tar file from request
    req.on('end', function(){
        fs.writeFile('upload.tar', JSON.parse(body)['data'], 'base64', function(err){
            res.send('Got your build!');
        });
    });
});

app.post('/api/projects/:project/adaptivejs/verify-dependencies/', function(req, res) {
    var errors = [];

    ['package.json', 'bower.json'].forEach(function(filename) {
        var filePath = path.join('test/fixtures', filename);
        var expected = fs.readFileSync(filePath, { encoding: 'utf8' });

        if (req.body[filename] != expected) {
            errors.push(filename + ' was not expected json');
        }
    });

    if (errors.length > 0) {
        res.send(errors.join(', '));
        return;
    }

    var payload = { success: true };
    res.send(JSON.stringify(payload));
});

var server = https.createServer(options, app);

// Grunt-express expects the server to have a use method
// We lost it when calling https.createServer
server.use = app.use;

module.exports = server;
